<?php
/**
 * Simple HTML Caching Plugin for AnonBlog
 */

return [
    'name' => 'Fast Cache',
    'description' => 'Speed up your site by caching rendered HTML pages.',
    'author' => 'AnonBlog Team',
    'version' => '1.0.0',
    'hooks' => [
        'system_init' => function() {
            // Do not cache for admin or POST requests
            if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false || $_SERVER['REQUEST_METHOD'] === 'POST') {
                return;
            }

            $cache_dir = __DIR__ . '/../../config/cache/';
            if (!is_dir($cache_dir)) mkdir($cache_dir, 0755, true);

            $cache_key = md5($_SERVER['REQUEST_URI'] . ($_SERVER['QUERY_STRING'] ?? ''));
            $cache_file = $cache_dir . $cache_key . '.html';

            // Cache expires in 1 hour (3600 seconds)
            if (file_exists($cache_file) && (time() - filemtime($cache_file) < 3600)) {
                echo file_get_contents($cache_file);
                echo "<!-- Cached version " . date('Y-m-d H:i:s', filemtime($cache_file)) . " -->";
                exit;
            }

            // Start output buffering to capture the rendered page
            ob_start(function($buffer) use ($cache_file) {
                if (strlen($buffer) > 100) { // Only cache if we actually have content
                    file_put_contents($cache_file, $buffer);
                }
                return $buffer;
            });
        },
        'post_saved' => function($slug) {
            // Clear cache when a post is saved
            clear_anon_cache();
        },
        'post_deleted' => function($slug) {
            clear_anon_cache();
        }
    ]
];

function clear_anon_cache() {
    $cache_dir = __DIR__ . '/../../config/cache/';
    if (is_dir($cache_dir)) {
        $files = glob($cache_dir . '*.html');
        foreach ($files as $file) {
            if (is_file($file)) unlink($file);
        }
    }
}
