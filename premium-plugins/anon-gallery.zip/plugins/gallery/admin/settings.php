<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/functions.php';

require_login('plugins');

$config = load_config();
$gallery_options = $config['gallery_options'] ?? [
    'columns' => 3,
    'gap' => 15,
    'border_radius' => 8,
    'show_caption' => true,
    'click_to_zoom' => true
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) die('CSRF Failed');
    
    $new_options = [
        'columns' => (int)$_POST['columns'],
        'gap' => (int)$_POST['gap'],
        'border_radius' => (int)$_POST['border_radius'],
        'show_caption' => isset($_POST['show_caption']),
        'click_to_zoom' => isset($_POST['click_to_zoom'])
    ];
    
    update_config(['gallery_options' => $new_options]);
    header("Location: settings.php?success=1");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gallery Settings - AnonBlog Admin</title>
    <link rel="stylesheet" href="../../../admin/style.css">
    <style>
        .main-content { margin-left: 310px; margin-top: 60px; padding: 20px; }
        .card { background: #fff; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input[type="number"], select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        .help-box { background: #e3f2fd; border-left: 5px solid #2196f3; padding: 15px; margin-bottom: 20px; }
        code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; font-weight: bold; }
    </style>
</head>
<body>
    <?php include "../../../admin/sidebar.php"; ?>
    <div class="main-content">
        <h1>Gallery Plugin Settings</h1>

        <div class="help-box">
            <h3>📖 How to use</h3>
            <p>To add a gallery to any post or page, use the following shortcode:</p>
            <p><code>[gallery images="image1.jpg, image2.png, photo.webp"]</code></p>
            <p><em>Tip: You can find filenames in the <strong>Media</strong> section. Copy the names of the images you want to include, separated by commas.</em></p>
        </div>

        <div class="card">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <div class="form-group">
                    <label>Columns (Desktop)</label>
                    <select name="columns">
                        <option value="2" <?php echo $gallery_options['columns'] == 2 ? 'selected' : ''; ?>>2 Columns</option>
                        <option value="3" <?php echo $gallery_options['columns'] == 3 ? 'selected' : ''; ?>>3 Columns</option>
                        <option value="4" <?php echo $gallery_options['columns'] == 4 ? 'selected' : ''; ?>>4 Columns</option>
                        <option value="5" <?php echo $gallery_options['columns'] == 5 ? 'selected' : ''; ?>>5 Columns</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Grid Gap (Pixels)</label>
                    <input type="number" name="gap" value="<?php echo $gallery_options['gap']; ?>">
                </div>

                <div class="form-group">
                    <label>Border Radius (Pixels)</label>
                    <input type="number" name="border_radius" value="<?php echo $gallery_options['border_radius']; ?>">
                </div>

                <div class="form-group">
                    <label><input type="checkbox" name="click_to_zoom" <?php echo $gallery_options['click_to_zoom'] ? 'checked' : ''; ?>> Enable click to view full image</label>
                </div>

                <button type="submit" class="btn btn-primary">Save Settings</button>
            </form>
        </div>
    </div>
</body>
</html>
