<?php
/**
 * Image Gallery Plugin for AnonBlog
 * Usage: [gallery images="image1.jpg,image2.jpg"]
 */

return [
    'name' => 'Simple Gallery',
    'description' => 'Add image galleries to your posts using [gallery images="img1,img2"] shortcode.',
    'author' => 'AnonBlog Team',
    'version' => '1.0.0',
    'hooks' => [
        'render_content' => function($content) {
            return preg_replace_callback('/\[gallery images="(.*?)"\]/', function($matches) {
                $images = explode(',', $matches[1]);
                $html = '<div class="anon-gallery" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin: 20px 0;">';
                foreach ($images as $img) {
                    $img = trim($img);
                    $thumb = "plugins/gallery/thumb.php?src=" . urlencode($img) . "&w=300&h=300";
                    $html .= '<a href="uploads/'.htmlspecialchars($img).'" target="_blank" class="gallery-item">';
                    $html .= '<img src="'.$thumb.'" style="width: 100%; height: 150px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd;">';
                    $html .= '</a>';
                }
                $html .= '</div>';
                return $html;
            }, $content);
        }
    ]
];
