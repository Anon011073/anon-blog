<?php
/**
 * Image Gallery Plugin for AnonBlog
 */

$config = load_config();
$gallery_options = $config['gallery_options'] ?? [
    'columns' => 3,
    'gap' => 15,
    'border_radius' => 8,
    'click_to_zoom' => true
];

return [
    'name' => 'Simple Gallery',
    'description' => 'Add image galleries to your posts using [gallery images="img1,img2"] shortcode.',
    'author' => 'AnonBlog Team',
    'version' => '1.2.0',
    'settings_url' => '../plugins/gallery/admin/settings.php',
    'hooks' => [
        'render_content' => function($content) use ($gallery_options) {
            return preg_replace_callback('/\[gallery images="(.*?)"\]/', function($matches) use ($gallery_options) {
                $images = explode(',', $matches[1]);
                $cols = $gallery_options['columns'];
                $gap = $gallery_options['gap'];
                $radius = $gallery_options['border_radius'];
                
                $html = '<div class="anon-gallery" style="display: grid; grid-template-columns: repeat('.$cols.', 1fr); gap: '.$gap.'px; margin: 25px 0;">';
                foreach ($images as $img) {
                    $img = trim($img);
                    if (empty($img)) continue;
                    
                    $thumb = "plugins/gallery/thumb.php?src=" . urlencode($img) . "&w=400&h=400";
                    $full = "uploads/" . htmlspecialchars($img);
                    
                    $html .= '<div class="gallery-item" style="overflow: hidden; border-radius: '.$radius.'px; border: 1px solid rgba(128,128,128,0.2); line-height: 0;">';
                    if ($gallery_options['click_to_zoom']) {
                        $html .= '<a href="'.$full.'" target="_blank" title="View Full Image">';
                    }
                    $html .= '<img src="'.$thumb.'" alt="'.$img.'" style="width: 100%; aspect-ratio: 1/1; object-fit: cover; transition: transform 0.3s ease;" onmouseover="this.style.transform=\'scale(1.05)\'" onmouseout="this.style.transform=\'scale(1)\'">';
                    if ($gallery_options['click_to_zoom']) {
                        $html .= '</a>';
                    }
                    $html .= '</div>';
                }
                $html .= '</div>';
                
                // Add mobile responsiveness
                $html .= '<style>@media (max-width: 768px) { .anon-gallery { grid-template-columns: repeat(2, 1fr) !important; } } @media (max-width: 480px) { .anon-gallery { grid-template-columns: 1fr !important; } }</style>';
                
                return $html;
            }, $content);
        }
    ]
];
