<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/functions.php';

require_login('plugins');

$file = __DIR__ . '/../../../config/likes.json';
$stats = file_exists($file) ? json_decode(file_get_contents($file), true) : [];

if (isset($_GET['reset'])) {
    if (!verify_csrf_token($_GET['csrf_token'] ?? '')) die('CSRF Failed');
    file_put_contents($file, json_encode([]));
    header("Location: settings.php?success=reset");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Like Stats - AnonBlog Admin</title>
    <link rel="stylesheet" href="../../../admin/style.css">
    <style>
        .main-content { margin-left: 310px; margin-top: 60px; padding: 20px; }
        .stats-table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stats-table th, .stats-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
        .stats-table th { background: #f8f9fa; font-weight: bold; }
        .btn-danger { background: #dc3545; color: white; padding: 8px 15px; border-radius: 4px; text-decoration: none; }
    </style>
</head>
<body>
    <?php include "../../../admin/sidebar.php"; ?>
    <div class="main-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h1>Post Like Statistics</h1>
            <a href="settings.php?reset=1&csrf_token=<?php echo get_csrf_token(); ?>" class="btn-danger" onclick="return confirm('Clear all like/dislike data?')">Reset All Stats</a>
        </div>

        <table class="stats-table">
            <thead>
                <tr>
                    <th>Post Slug</th>
                    <th>Likes</th>
                    <th>Dislikes</th>
                    <th>Ratio</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($stats)): ?>
                    <tr><td colspan="4" style="text-align: center;">No data yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($stats as $slug => $data): 
                        $total = $data['likes'] + $data['dislikes'];
                        $ratio = $total > 0 ? round(($data['likes'] / $total) * 100) : 0;
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($slug); ?></td>
                            <td>👍 <?php echo $data['likes']; ?></td>
                            <td>👎 <?php echo $data['dislikes']; ?></td>
                            <td>
                                <div style="width: 100px; height: 10px; background: #eee; border-radius: 5px; overflow: hidden;">
                                    <div style="width: <?php echo $ratio; ?>%; height: 100%; background: #28a745;"></div>
                                </div>
                                <small><?php echo $ratio; ?>% positive</small>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
