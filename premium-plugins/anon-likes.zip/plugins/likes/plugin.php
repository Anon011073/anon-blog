<?php
/**
 * Like/Dislike Plugin for AnonBlog
 */

return [
    'name' => 'Likes & Dislikes',
    'description' => 'Add simple like and dislike buttons to your posts.',
    'author' => 'AnonBlog Team',
    'version' => '1.1.0',
    'settings_url' => '../plugins/likes/admin/settings.php',
    'assets' => [
        'css' => [],
        'js' => []
    ],
    'hooks' => [
        'render_content' => function($content) {
            if (isset($_GET['post'])) {
                $slug = $_GET['post'];
                $counts = get_like_counts($slug);
                
                $html = '
                <div class="anon-likes" data-slug="'.htmlspecialchars($slug).'" style="margin-top: 20px; padding: 15px; border-top: 1px solid rgba(128,128,128,0.2); display: flex; gap: 20px; align-items: center;">
                    <button type="button" class="like-btn" onclick="anonLike(\''.$slug.'\', \'like\')" style="background: rgba(128,128,128,0.1); border: 1px solid rgba(128,128,128,0.3); padding: 8px 18px; cursor: pointer; border-radius: 6px; color: inherit; font-size: 1.1rem; display: flex; align-items: center; gap: 8px; transition: 0.2s;">
                        <span>👍</span> <span class="like-count">'.$counts['likes'].'</span>
                    </button>
                    <button type="button" class="dislike-btn" onclick="anonLike(\''.$slug.'\', \'dislike\')" style="background: rgba(128,128,128,0.1); border: 1px solid rgba(128,128,128,0.3); padding: 8px 18px; cursor: pointer; border-radius: 6px; color: inherit; font-size: 1.1rem; display: flex; align-items: center; gap: 8px; transition: 0.2s;">
                        <span>👎</span> <span class="dislike-count">'.$counts['dislikes'].'</span>
                    </button>
                </div>
                <script>
                if (typeof anonLike !== "function") {
                    function anonLike(slug, type) {
                        fetch("plugins/likes/ajax.php?slug=" + slug + "&type=" + type)
                        .then(response => response.json())
                        .then(data => {
                            if(data.success) {
                                document.querySelector(".like-count").innerText = data.likes;
                                document.querySelector(".dislike-count").innerText = data.dislikes;
                                if(data.message === "Already voted") {
                                    alert("You have already voted on this post.");
                                }
                            }
                        }).catch(err => console.error("Like error:", err));
                    }
                }
                </script>
                ';
                return $content . $html;
            }
            return $content;
        }
    ]
];

if (!function_exists('get_like_counts')) {
    function get_like_counts($slug) {
        $file = __DIR__ . '/../../config/likes.json';
        $data = [];
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true) ?: [];
        }
        return $data[$slug] ?? ['likes' => 0, 'dislikes' => 0];
    }
}
