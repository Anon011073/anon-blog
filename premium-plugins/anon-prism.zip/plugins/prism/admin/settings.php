<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/functions.php';

require_login('plugins');

$config = load_config();
$prism_config = $config['prism_options'] ?? [
    'theme' => 'prism',
    'line_numbers' => false,
    'copy_button' => false
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'])) die('CSRF Failed');
    
    $new_prism = [
        'theme' => $_POST['theme'],
        'line_numbers' => isset($_POST['line_numbers']),
        'copy_button' => isset($_POST['copy_button'])
    ];
    
    update_config(['prism_options' => $new_prism]);
    header("Location: settings.php?success=1");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Prism Settings - AnonBlog Admin</title>
    <style>
        body { font-family: sans-serif; margin: 0; display: flex; min-height: 100vh; background: #f4f4f4; }
        .main-content { flex: 1; padding: 2rem; margin-left: 310px; margin-top: 50px; }
        .card { background: #fff; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: bold; }
        select, .btn { padding: 0.5rem 1rem; border-radius: 4px; }
        .btn-primary { background: #007bff; color: #fff; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <?php include "../../../admin/sidebar.php"; ?>
    <div class="main-content">
        <h1>Prism Syntax Highlighter Settings</h1>
        <div class="card">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                <div class="form-group">
                    <label>Prism Theme</label>
                    <select name="theme">
                        <option value="prism" <?php echo $prism_config['theme'] == 'prism' ? 'selected' : ''; ?>>Default</option>
                        <option value="prism-dark" <?php echo $prism_config['theme'] == 'prism-dark' ? 'selected' : ''; ?>>Dark</option>
                        <option value="prism-okaidia" <?php echo $prism_config['theme'] == 'prism-okaidia' ? 'selected' : ''; ?>>Okaidia</option>
                        <option value="prism-tomorrow" <?php echo $prism_config['theme'] == 'prism-tomorrow' ? 'selected' : ''; ?>>Tomorrow Night</option>
                        <option value="prism-twilight" <?php echo $prism_config['theme'] == 'prism-twilight' ? 'selected' : ''; ?>>Twilight</option>
                    </select>
                </div>
                <div class="form-group">
                    <label><input type="checkbox" name="line_numbers" <?php echo $prism_config['line_numbers'] ? 'checked' : ''; ?>> Show Line Numbers</label>
                </div>
                <div class="form-group">
                    <label><input type="checkbox" name="copy_button" <?php echo $prism_config['copy_button'] ? 'checked' : ''; ?>> Enable Copy Button</label>
                </div>
                <button type="submit" class="btn btn-primary">Save Prism Settings</button>
            </form>
        </div>
    </div>
</body>
</html>
