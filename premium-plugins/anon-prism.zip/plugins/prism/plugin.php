<?php
/**
 * Prism Syntax Highlighter for AnonBlog
 */

$config = load_config();
$prism_options = $config['prism_options'] ?? ['theme' => 'prism', 'line_numbers' => false, 'copy_button' => false];
$theme = $prism_options['theme'];

$assets = [
    'css' => ["https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/{$theme}.min.css"],
    'js' => ["https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"]
];

if ($prism_options['line_numbers']) {
    $assets['css'][] = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/line-numbers/prism-line-numbers.min.css";
    $assets['js'][] = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/line-numbers/prism-line-numbers.min.js";
}

if ($prism_options['copy_button']) {
    $assets['css'][] = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/copy-to-clipboard/prism-copy-to-clipboard.min.css";
    $assets['js'][] = "https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/copy-to-clipboard/prism-copy-to-clipboard.min.js";
}

return [
    'name' => 'Prism.js Syntax Highlighter',
    'description' => 'Beautiful syntax highlighting for your code blocks.',
    'author' => 'AnonBlog Team',
    'version' => '1.1.0',
    'settings_url' => '../plugins/prism/admin/settings.php',
    'assets' => $assets,
    'hooks' => [
        'render_content' => function($content) use ($prism_options) {
            // Clean up artifacts from Jodit and apply Prism classes
            $content = preg_replace_callback('/<pre[^>]*><code[^>]*>(.*?)<\/code><\/pre>/is', function($matches) use ($prism_options) {
                $inner = $matches[1];
                $inner = str_replace(['&nbsp;', '<br>', '<br />', '<div>', '</div>'], [" ", "\n", "\n", "", "\n"], $inner);
                $inner = html_entity_decode($inner);
                $inner = htmlspecialchars($inner);
                
                $classes = $prism_options['line_numbers'] ? 'line-numbers' : '';
                return "<pre class=\"{$classes}\"><code>$inner</code></pre>";
            }, $content);
            return $content;
        }
    ]
];
