<?php
require_once __DIR__ . '/../../../app/auth.php';
require_once __DIR__ . '/../../../app/functions.php';
require_once __DIR__ . '/../../../app/posts.php';

require_login('plugins');

$success = '';
$sitemap_file = __DIR__ . '/../../../sitemap.xml';

if (isset($_POST['generate'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) die('CSRF Failed');

    $root = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
    $base = str_replace(['index.php', 'admin/', 'plugins/anon-sitemap/admin/settings.php'], '', $_SERVER['SCRIPT_NAME']);
    $site_url = rtrim($root . $base, '/');

    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
    $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;
    
    // Home
    $xml .= '  <url><loc>' . $site_url . '/</loc><priority>1.0</priority></url>' . PHP_EOL;
    
    // Posts
    foreach (get_posts() as $p) {
        $xml .= '  <url><loc>' . $site_url . '/?post=' . $p['slug'] . '</loc><priority>0.8</priority></url>' . PHP_EOL;
    }
    
    $xml .= '</urlset>';
    
    if (file_put_contents($sitemap_file, $xml)) {
        $success = "Sitemap generated successfully!";
    }
}

if (isset($_POST['delete'])) {
    if (!verify_csrf_token($_POST['csrf_token'])) die('CSRF Failed');
    if (file_exists($sitemap_file)) {
        unlink($sitemap_file);
        $success = "Sitemap deleted.";
    }
}

$exists = file_exists($sitemap_file);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sitemap Settings - AnonBlog Admin</title>
    <link rel="stylesheet" href="../../../admin/style.css">
    <style>.main-content { margin-left: 310px; margin-top: 60px; padding: 20px; }</style>
</head>
<body>
    <?php include "../../../admin/sidebar.php"; ?>
    <div class="main-content">
        <h1>Sitemap Management</h1>
        
        <?php if ($success): ?>
            <div style="background: #d4edda; color: #155724; padding: 10px; margin-bottom: 20px; border-radius: 4px;"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="card">
            <p>Generate a physical <code>sitemap.xml</code> file in your site root for SEO.</p>
            
            <?php if ($exists): ?>
                <div style="background: #e3f2fd; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
                    <strong>Current Sitemap:</strong> <a href="../../../sitemap.xml" target="_blank">View sitemap.xml</a>
                    <br><small>Last updated: <?php echo date('Y-m-d H:i:s', filemtime($sitemap_file)); ?></small>
                </div>
            <?php else: ?>
                <p><em>No sitemap.xml found in root.</em></p>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                <button type="submit" name="generate" class="btn btn-primary">Generate Sitemap</button>
                <?php if ($exists): ?>
                    <button type="submit" name="delete" class="btn btn-danger" onclick="return confirm('Delete sitemap.xml?')">Delete Sitemap</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</body>
</html>
