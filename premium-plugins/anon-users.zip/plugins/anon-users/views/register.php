<div class="anon-users-register" style="color: #333;">
    <?php if (isset($_SESSION['anon_error'])): ?>
        <div style="background: #f2dede; color: #a94442; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
            <?php echo $_SESSION['anon_error']; unset($_SESSION['anon_error']); ?>
        </div>
    <?php endif; ?>

    <form method="POST" style="max-width: 450px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border: 1px solid #eee;">
        <h3 style="margin-top: 0; text-align: center; color: #333; font-size: 1.5rem; margin-bottom: 25px;">Create Account</h3>
        <input type="hidden" name="anon_action" value="register">
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 8px; font-weight: bold; color: #444;">Username</label>
            <input type="text" name="username" required style="width: 100%; padding: 12px; border: 2px solid #eee; border-radius: 6px; box-sizing: border-box; font-size: 1rem; color: #333; outline: none; transition: border-color 0.3s;">
        </div>

        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 8px; font-weight: bold; color: #444;">Nickname (Display Name)</label>
            <input type="text" name="nickname" required style="width: 100%; padding: 12px; border: 2px solid #eee; border-radius: 6px; box-sizing: border-box; font-size: 1rem; color: #333; outline: none; transition: border-color 0.3s;">
        </div>

        <div style="margin-bottom: 25px;">
            <label style="display: block; margin-bottom: 8px; font-weight: bold; color: #444;">Password</label>
            <input type="password" name="password" required style="width: 100%; padding: 12px; border: 2px solid #eee; border-radius: 6px; box-sizing: border-box; font-size: 1rem; color: #333; outline: none; transition: border-color 0.3s;">
        </div>

        <button type="submit" style="width: 100%; padding: 14px; background: #28a745; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-size: 1rem; font-weight: bold; transition: background 0.3s;">Register Account</button>
        
        <p style="margin-top: 25px; text-align: center; font-size: 0.9rem; color: #666;">
            Already have an account? <a href="index.php?page=login" style="color: #2271b1; text-decoration: none; font-weight: bold;">Login here</a>
        </p>
    </form>
    <style>
        .anon-users-register input:focus { border-color: #28a745 !important; }
        .anon-users-register button:hover { background: #218838 !important; }
    </style>
</div>
